// const response = await fetch("https://virsys.metered.live/api/v1/turn/credentials?apiKey=ca9f4e60bf446fc29401ccb1fa904d110708");
// const iceServers = await response.json();


function AddNewUser(other_user_id, connId) {
    var $newDiv = $('#otherTemplate').clone();
    $newDiv = $newDiv.attr('id', connId).addClass('other');
    $newDiv.find('h2').text(other_user_id);
    $newDiv.find('video').attr('id', 'v_' + connId);
    $newDiv.find('audio').attr('id', 'a_' + connId);
    $newDiv.show();
    $('#divUsers').append($newDiv);
}
var WrtcHelper = (function () {

    // let iceConfiguration = {
    //     //  iceServers: [
    //     //      {urls:'stun:stun.l.google.com:19302'},
    //     //  	{urls:'stun:stun1.l.google.com:19302'},
    //     //  	{urls:'stun:stun2.l.google.com:19302'},
    //     //  	{urls:'stun:stun3.l.google.com:19302'},
    //     //  	{urls:'stun:stun4.l.google.com:19302'},
    //     //    ]
    //     iceServers: iceServers
    // };
    let iceConfiguration
    var _audioTrack;

    var peers_conns = [];
    var peers_con_ids = [];

    var politePeersState = [];
    var offerMakingStatePeers = [];

    var _remoteVideoStreams = [];
    var _remoteAudioStreams = [];

    var _localVideoPlayer;

    var _rtpVideoSenders = [];
    var _rtpAudioSenders = [];

    var _serverFn;

    var VideoStates = { None: 0, Camera: 1, ScreenShare: 2 };
    var _videoState = VideoStates.None;
    var _videoCamSSTrack;
    var _isAudioMute = true;
    var _my_connid = '';

    async function _init(serFn, myconnid, iceServers,) {
        _my_connid = myconnid;
        _serverFn = serFn;
        iceConfiguration = {
            iceServers: iceServers
        }
        _localVideoPlayer = document.getElementById('localVideoCtr');
        // await ManageVideo(VideoStates.Camera); 
        eventBinding();
    }

    function eventBinding() {
        $("#btnMuteUnmute").on('click', async function () {

            if (!_audioTrack) {
                await startwithAudio();
            }

            if (!_audioTrack) {
                alert('problem with audio permission')
                return;
            }

            if (_isAudioMute) {
                _audioTrack.enabled = true;
                $(this).text("Mute");
                AddUpdateAudioVideoSenders(_audioTrack, _rtpAudioSenders);
            }
            else {
                _audioTrack.enabled = false;
                $(this).text("Unmute");

                RemoveAudioVideoSenders(_rtpAudioSenders);
            }
            _isAudioMute = !_isAudioMute;

            console.log(_audioTrack);
        });
        $("#btnStartStopCam").on('click', async function () {

            if (_videoState == VideoStates.Camera) { //Stop case
                await ManageVideo(VideoStates.None);
            }
            else {
                await ManageVideo(VideoStates.Camera);
            }
        });
        $("#btnStartStopScreenshare").on('click', async function () {

            if (_videoState == VideoStates.ScreenShare) { //Stop case
                await ManageVideo(VideoStates.None);
            }
            else {
                await ManageVideo(VideoStates.ScreenShare);
            }
        });
    }
    //Camera or Screen Share or None
    async function ManageVideo(_newVideoState) {

        if (_newVideoState == VideoStates.None) {
            $("#btnStartStopCam").text('Start Camera');
            $("#btnStartStopScreenshare").text('Screen Share');
            _videoState = _newVideoState;

            ClearCurrentVideoCamStream(_rtpVideoSenders);
            return;
        }

        try {
            var vstream = null;

            if (_newVideoState == VideoStates.Camera) {
                vstream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        width: 720,
                        height: 480
                    },
                    audio: false
                });
            }
            else if (_newVideoState == VideoStates.ScreenShare) {
                vstream = await navigator.mediaDevices.getDisplayMedia({
                    video: {
                        width: 720,
                        height: 480
                    },
                    audio: false
                });

                vstream.oninactive = e => {
                    ClearCurrentVideoCamStream(_rtpVideoSenders);
                    $("#btnStartStopScreenshare").text('Screen Share');
                };
            }

            ClearCurrentVideoCamStream(_rtpVideoSenders);

            _videoState = _newVideoState;

            if (_newVideoState == VideoStates.Camera) {
                $("#btnStartStopCam").text('Stop Camera');
                $("#btnStartStopScreenshare").text('Screen Share');
            }
            else if (_newVideoState == VideoStates.ScreenShare) {
                $("#btnStartStopCam").text('Start Camera');
                $("#btnStartStopScreenshare").text('Stop Screen Share');
            }

            if (vstream && vstream.getVideoTracks().length > 0) {
                _videoCamSSTrack = vstream.getVideoTracks()[0];

                if (_videoCamSSTrack) {
                    _localVideoPlayer.srcObject = new MediaStream([_videoCamSSTrack]);

                    AddUpdateAudioVideoSenders(_videoCamSSTrack, _rtpVideoSenders);
                }
            }
        } catch (e) {
            console.log(e);
            return;
        }
    }

    function ClearCurrentVideoCamStream(rtpVideoSenders) {
        if (_videoCamSSTrack) {
            _videoCamSSTrack.stop();
            _videoCamSSTrack = null;
            _localVideoPlayer.srcObject = null;

            RemoveAudioVideoSenders(rtpVideoSenders);
        }
    }

    async function RemoveAudioVideoSenders(rtpSenders) {
        for (var con_id in peers_con_ids) {
            if (rtpSenders[con_id] && IsConnectionAvailable(peers_conns[con_id])) {
                peers_conns[con_id].removeTrack(rtpSenders[con_id]);
                rtpSenders[con_id] = null;
            }
        }
    }

    async function AddUpdateAudioVideoSenders(track, rtpSenders) {
        for (var con_id in peers_con_ids) {
            if (IsConnectionAvailable(peers_conns[con_id])) {
                if (rtpSenders[con_id] && rtpSenders[con_id].track) {
                    rtpSenders[con_id].replaceTrack(track);
                }
                else {
                    rtpSenders[con_id] = peers_conns[con_id].addTrack(track);
                }
            }
        }
    }

    async function startwithAudio() {

        try {
            var astream = await navigator.mediaDevices.getUserMedia({ video: false, audio: true });
            _audioTrack = astream.getAudioTracks()[0];

            _audioTrack.onmute = function (e) {
                console.log(e);
            }
            _audioTrack.onunmute = function (e) {
                console.log(e);
            }

            _audioTrack.enabled = false;

        } catch (e) {
            console.log(e);
            return;
        }
    }

    async function createConnection(connid,peerSate) {
        console.log('createConnection', connid,iceConfiguration);
        var connection = new RTCPeerConnection(iceConfiguration);
        connection.onicecandidate = function (event) {
            console.log('onicecandidate', event.candidate);
            if (event.candidate) {
                _serverFn(JSON.stringify({ 'iceCandidate': event.candidate }), connid);
            }
        }
        connection.onicecandidateerror = function (event) {
            console.log('onicecandidateerror', event);

        }
        connection.onicegatheringstatechange = function (event) {
            console.log('onicegatheringstatechange', event);
        };
        connection.onnegotiationneeded = async function (event) {
            console.log('onnegotiationneeded', event);
            await _createOffer(connid);
        }
      	connection.oniceconnectionstatechange = () => {
            console.log(this.id +  ' peer ice connection state: ', connection.iceConnectionState);
            if (connection.iceConnectionState === "failed") {
                connection.restartIce();
            }
        }
        connection.onconnectionstatechange = function (event) {

            console.log('onconnectionstatechange', event.currentTarget.connectionState)
            if (event.currentTarget.connectionState === "connected") {
                console.log('connected')
            }
            if (event.currentTarget.connectionState === "disconnected") {
                console.log('disconnected');
            }
        }
        // New remote media stream was added
        connection.ontrack = function (event) {

            // event.track.onunmute = () => {
            //     alert('unmuted');
            // };     

            if (!_remoteVideoStreams[connid]) {
                _remoteVideoStreams[connid] = new MediaStream();
            }

            if (!_remoteAudioStreams[connid])
                _remoteAudioStreams[connid] = new MediaStream();

            if (event.track.kind == 'video') {
                _remoteVideoStreams[connid].getVideoTracks().forEach(t => _remoteVideoStreams[connid].removeTrack(t));
                _remoteVideoStreams[connid].addTrack(event.track);
                //_remoteVideoStreams[connid].getTracks().forEach(t => console.log(t));

                var _remoteVideoPlayer = document.getElementById('v_' + connid)
                _remoteVideoPlayer.srcObject = null;
                _remoteVideoPlayer.srcObject = _remoteVideoStreams[connid];
                _remoteVideoPlayer.load();
                //$(_remoteVideoPlayer).show();

                // event.track.onmute = function() {
                //     console.log(connid + ' muted');
                //    console.log(this.muted+ ' muted');
                //    console.log(event.track.muted+ ' muted');
                //    console.log(this.readyState+ ' muted');
                //    console.log('muted',this);
                //    console.log('muted',_remoteVideoStreams[connid] );
                //    console.log('muted',_remoteVideoPlayer.paused);
                //    console.log('muted',_remoteVideoPlayer.readyState );
                //    console.log('muted',_remoteVideoPlayer.ended );
                //    if(this.muted){
                //     //_remoteVideoPlayer.srcObject = null;
                //    }
                // };
            }
            else if (event.track.kind == 'audio') {
                var _remoteAudioPlayer = document.getElementById('a_' + connid)
                _remoteAudioStreams[connid].getVideoTracks().forEach(t => _remoteAudioStreams[connid].removeTrack(t));
                _remoteAudioStreams[connid].addTrack(event.track);
                _remoteAudioPlayer.srcObject = null;
                _remoteAudioPlayer.srcObject = _remoteAudioStreams[connid];
                _remoteAudioPlayer.load();
            }
        };

        peers_con_ids[connid] = connid;
        peers_conns[connid] = connection;
        politePeersState[connid] = peerSate;

        if (_videoState == VideoStates.Camera || _videoState == VideoStates.ScreenShare) {
            if (_videoCamSSTrack) {
                AddUpdateAudioVideoSenders(_videoCamSSTrack, _rtpVideoSenders);
            }
        }

        return connection;
    }

    async function _createOffer(connid) {
        try {

        
        //await createConnection();
        var connection = peers_conns[connid];
        offerMakingStatePeers[connid] = true;
        console.log('connection.signalingState:' + connection.signalingState);
        var offer = await connection.createOffer();
        await connection.setLocalDescription(offer);
        //Send offer to Server
        _serverFn(JSON.stringify({ 'offer': connection.localDescription }), connid);
        }
        catch (err) {
            console.error(err);
        }
        finally{
            offerMakingStatePeers[connid] = false;
        }
    }
    async function exchangeSDP(message, from_connid) {
        console.log('messag', message);
        message = JSON.parse(message);

        if (message.answer) {
            console.log('answer', message.answer);
            await peers_conns[from_connid].setRemoteDescription(new RTCSessionDescription(message.answer));
            console.log('connection', peers_conns[from_connid]);
        }
        else if (message.offer) {
            console.log('offer', message.offer);

            if (!peers_conns[from_connid]) {
                console.log("after offter , no peer creating connection", from_connid);
                await createConnection(from_connid,false);
                AddNewUser(from_connid, from_connid);

            }
            const offerCollision = (offerMakingStatePeers[from_connid] || peers_conns[from_connid].signalingState !== "stable");
            if(offerCollision && !politePeersState[from_connid]){
                console.log("ignoring Offer",from_connid);
                return;
            } 

            await peers_conns[from_connid].setRemoteDescription(new RTCSessionDescription(message.offer));
            var answer = await peers_conns[from_connid].createAnswer();
            await peers_conns[from_connid].setLocalDescription();
            _serverFn(JSON.stringify({ 'answer': peers_conns[from_connid].localDescription }), from_connid);
        }
        else if (message.iceCandidate) {
            console.log('iceCandidate', message.iceCandidate);
            if (!peers_conns[from_connid]) {
                console.log("after offter , no peer creating connection", from_connid);
                await createConnection(from_connid, false);
                AddNewUser(from_connid, from_connid);
            }

            try {
                await peers_conns[from_connid].addIceCandidate(message.iceCandidate);
            } catch (e) {
                console.log(e);
            }
        }
    }

    function IsConnectionAvailable(connection) {
        if (connection &&
            (connection.connectionState == "new"
                || connection.connectionState == "connecting"
                || connection.connectionState == "connected"
            )) {
            return true;
        }
        else
            return false;
    }
    function closeConnection(connid) {

        peers_con_ids[connid] = null;

        if (peers_conns[connid]) {
            peers_conns[connid].close();
            peers_conns[connid] = null;
        }
        if (_remoteAudioStreams[connid]) {
            _remoteAudioStreams[connid].getTracks().forEach(t => {
                if (t.stop)
                    t.stop();
            });
            _remoteAudioStreams[connid] = null;
        }

        if (_remoteVideoStreams[connid]) {
            _remoteVideoStreams[connid].getTracks().forEach(t => {
                if (t.stop)
                    t.stop();
            });
            _remoteVideoStreams[connid] = null;
        }
    }
    return {
        init: async function (serverFn, my_connid, iceServers) {
            await _init(serverFn, my_connid, iceServers);
        },
        ExecuteClientFn: async function (data, from_connid) {
            await exchangeSDP(data, from_connid);
        },
        createNewConnection: async function (connid,peerState=true) {
            await createConnection(connid,peerState);
        },
        closeExistingConnection: function (connid) {
            closeConnection(connid);
        }
    }
}());